# AutoHiDPI

https://addons.mozilla.org/en-US/firefox/addon/autohidpi/

**Author:** Ertug Karamatli <ertug@karamatli.com>

## Contributors

* Alexander Early
* Arnout Engelen
* Enrico Carlesso
* Hermann Mayer
* Jason Uher
* Kevin Azzam
