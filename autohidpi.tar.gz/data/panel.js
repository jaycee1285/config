"use strict";

const geometry = document.getElementById("geometry");
const pixelRatioInput = document.getElementById("pixelRatio");
const pixelRatioDisplay = document.getElementById("pixelRatioDisplay");

function updateDisplay(screen, pixelRatio) {
  geometry.textContent = `width=${screen.width} height=${screen.height} left=${screen.left} top=${screen.top}`;
  pixelRatioInput.value = pixelRatio;
  pixelRatioDisplay.textContent = pixelRatio + "x";
}

// Update display as user drags slider
pixelRatioInput.addEventListener("input", (event) => {
  pixelRatioDisplay.textContent = event.target.value + "x";
});

// Save when user releases slider
pixelRatioInput.addEventListener("change", async (event) => {
  const pixelRatio = parseFloat(event.target.value);
  await browser.runtime.sendMessage({
    type: "setPixelRatio",
    pixelRatio
  });
});

// Get initial state from background script
(async () => {
  const state = await browser.runtime.sendMessage({ type: "getState" });
  if (state.error) {
    geometry.textContent = state.error;
  } else {
    updateDisplay(state.screen, state.pixelRatio);
  }
})();
