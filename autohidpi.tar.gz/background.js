"use strict";

const DEFAULT_PIXEL_RATIO = 1;
const UPDATE_INTERVAL_MS = 500;

let currentPixelRatio = null;
let lastScreenId = null;
let timerId = null;

// Storage functions
async function loadPixelRatios() {
  const result = await browser.storage.local.get("pixelRatios");
  return result.pixelRatios || {};
}

async function loadPixelRatio(screenId) {
  const pixelRatios = await loadPixelRatios();
  return pixelRatios[screenId] || DEFAULT_PIXEL_RATIO;
}

async function savePixelRatio(screenId, pixelRatio) {
  const pixelRatios = await loadPixelRatios();
  pixelRatios[screenId] = pixelRatio;
  await browser.storage.local.set({ pixelRatios });
}

// Preference functions using experiment API
async function setDevPixelsPerPx(pixelRatio) {
  if (pixelRatio && pixelRatio !== currentPixelRatio) {
    console.log("setDevPixelsPerPx", pixelRatio);
    await browser.prefs.set("layout.css.devPixelsPerPx", String(pixelRatio));
    currentPixelRatio = pixelRatio;
  }
}

async function resetDevPixelsPerPx() {
  await setDevPixelsPerPx(DEFAULT_PIXEL_RATIO);
}

// Get screen info from the focused window via content script injection
async function getActiveScreenInfo() {
  try {
    const [activeTab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!activeTab?.id) {
      return null;
    }

    // Inject a script to get screen geometry
    const results = await browser.tabs.executeScript(activeTab.id, {
      code: `({
        width: window.screen.width,
        height: window.screen.height,
        left: window.screen.availLeft || 0,
        top: window.screen.availTop || 0
      })`
    });

    return results?.[0] || null;
  } catch (e) {
    console.log("Could not get screen info:", e.message);
    return null;
  }
}

function buildScreenId(screen) {
  return [screen.width, screen.height, screen.left, screen.top].join(",");
}

// Main update function
async function update(force = false) {
  console.log("update", force);

  // Reset DPI first to get accurate screen measurements
  await resetDevPixelsPerPx();

  const screen = await getActiveScreenInfo();
  if (!screen) {
    console.log("No screen info available");
    return null;
  }

  const screenId = buildScreenId(screen);

  if (force || lastScreenId !== screenId) {
    console.log("active screen changed", screenId);

    const pixelRatio = await loadPixelRatio(screenId);
    console.log("loaded pixelRatio", pixelRatio);

    await setDevPixelsPerPx(pixelRatio);

    lastScreenId = screenId;

    return {
      screen,
      pixelRatio
    };
  }

  return null;
}

// Message handling for popup
browser.runtime.onMessage.addListener(async (message, sender) => {
  console.log("Received message:", message);

  if (message.type === "getState") {
    // Force update and return current state
    await resetDevPixelsPerPx();

    const screen = await getActiveScreenInfo();
    if (!screen) {
      return { error: "Could not get screen info" };
    }

    const screenId = buildScreenId(screen);
    const pixelRatio = await loadPixelRatio(screenId);

    await setDevPixelsPerPx(pixelRatio);
    lastScreenId = screenId;

    return { screen, pixelRatio };
  }

  if (message.type === "setPixelRatio") {
    await resetDevPixelsPerPx();

    const screen = await getActiveScreenInfo();
    if (!screen) {
      return { error: "Could not get screen info" };
    }

    const screenId = buildScreenId(screen);
    await savePixelRatio(screenId, message.pixelRatio);
    console.log("saved pixelRatio", message.pixelRatio);

    await setDevPixelsPerPx(message.pixelRatio);
    lastScreenId = screenId;

    return { success: true };
  }

  return { error: "Unknown message type" };
});

// Polling for screen changes
function startPolling() {
  if (!timerId) {
    console.log("Starting polling");
    timerId = setInterval(() => update(false), UPDATE_INTERVAL_MS);
  }
}

function stopPolling() {
  if (timerId) {
    console.log("Stopping polling");
    clearInterval(timerId);
    timerId = null;
  }
}

// Use idle API instead of user-interaction events
browser.idle.onStateChanged.addListener((state) => {
  console.log("Idle state changed:", state);
  if (state === "active") {
    startPolling();
  } else {
    stopPolling();
  }
});

// Also poll when windows gain focus
browser.windows.onFocusChanged.addListener((windowId) => {
  if (windowId !== browser.windows.WINDOW_ID_NONE) {
    update(true);
  }
});

// Initial setup
(async () => {
  await update(true);
  startPolling();
})();
